<template>
  <div class="hello">
    <IndexMenuBar></IndexMenuBar>

  </div>
</template>

<script>
  import IndexMenuBar from './IndexMenuBar.vue';

  export default {
    name: 'HelloWorld',
    components:{
      IndexMenuBar,

    }
  }
</script>


<style scoped>
</style>
