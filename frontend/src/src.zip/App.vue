<template>
  <div id="app">
    <HelloWorld></HelloWorld>
    <div id="root">
	  <button class="btn" @click="showModal=true">Show</button>
	  <modal v-if="showModal" @close="showModal = false" name="Umesh">
			<p>dsfkdskf</p>
	  </modal>
    </div>
    <h1>박준수</h1>
  </div>
</template>

<script>
import HelloWorld from '@/components/HelloWorld.vue';
import ServiceEnroll from '@/components/servicecoms/ServiceEnroll.vue';
export default{
  components:{
    HelloWorld,
    ServiceEnroll
  }
}
</script>

