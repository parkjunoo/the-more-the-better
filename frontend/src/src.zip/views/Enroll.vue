<template>
    <ServiceEnroll></ServiceEnroll> 
</template>

<script>
// @ is an alias to /src
import ServiceEnroll from '@/components/servicecoms/ServiceEnroll.vue'

export default {
  name: 'ServiceEnrolle',
  components: {
    ServiceEnroll
  }
}
</script>