# the-more-the-better
플레이데이터 Pose-Estimation 개발자 교육 과정 중간 프로젝트 - '다다익선(多多益善)'

## Data Model Diagram
바뀔수 있어요!

![dadaDiagram](https://user-images.githubusercontent.com/64248514/91996885-73063f80-ed74-11ea-89aa-13cca86d9b8a.png)

Member : 사용자 <br>
Class : 개설된 반 <br>
Store : 등록되어 있는 가게 <br>
Waiting : 현재 진행중인 주문 <br>
Host : 주문을 연 호스트 <br>
Waiting_Mems : 진행중인 주문의 대기자 모임 <br>
Event : 가게에서 진행중인 이벤트 <br>
