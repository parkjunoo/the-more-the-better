package io.playdata.themorethebetter.exception;

public class ForbiddenException extends RuntimeException {
	public ForbiddenException(String str) {
		super(str);
	}
}
